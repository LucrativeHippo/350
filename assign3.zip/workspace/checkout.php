<script>
    var myCart = JSON.stringify(sessionStorage["shoppingList"]);
</script>
<?php
// A simple web site in Cloud9 that runs through Apache
// Press the 'Run' button on the top to start the web server,
// then click the URL that is emitted to the Output tab of the console

$servername = getenv('IP');

$username = getenv('C9_USER');
$password = "";
$database = "Products";
$dbport = 3306;

//Create connection
$db = new mysqli($servername, $username, $password,$database,$dbport);

//Check Connection
if ($db->connect_error){
    die("Connection failed: " . $db->connect_error);
}


//check for customer in database
$check_customer = "SELECT * FROM Customers WHERE name='".$_POST['name']."' LIMIT 1";
$customer_result= mysqli_query($db,$check_customer);

//echo "POST(".$_POST['name'].")";
$r = mysqli_fetch_assoc($customer_result);
//echo "DATA(".$r['name'].")";
if($_POST['name'] == $r['name']){
    //echo "In database";
}else{
    $query_project = "INSERT INTO Customers VALUES ('".$_POST['name']."','".$_POST['address']."','".$_POST['city']."','".$_POST['province']."','".$_POST['email']."','".$_POST['ccnum']."')";
    mysqli_query($db,$query_project);
    //echo "not in data";
}






$items = $_POST['items'];
$items = substr($items,1,strlen($items)-2);
$items = str_replace('\\','',$items);
$final = json_decode($items,true);

/*
print $dl;
print $dl."item_obj:";
print $item_obj[0];
$test = $item_obj[0];
print $test['itemPrice'];
*/


for ($i=0;$i<sizeof($final);$i++){
    $item = $final[$i];
    //print $item['itemPrice'];
    //print "(".$i.")";
    $insert_query = "INSERT INTO Transactions (customerName,productName,date,price) VALUES ('".$_POST['name']."','".$item["itemDescription"]."','".date("dMY")."','".$item['itemPrice']."')";
    //print $insert_query;
    mysqli_query($db,$insert_query);
    //should query the database for price of item, but lazy
    // $query_project = "SELECT * FROM Products WHERE itemDescription='".$item["itemDescription"]." LIMIT 1'";
    // $qItem = mysqli_query($db,$query_project);
    // while($r = mysqli_fetch_assoc($qItem)){
    // //    echo "R(".$r['itemPrice'].")";
    // }
    //echo $item["itemPrice"];
}
/*

echo '[';


$startItem=true;
while($r = mysqli_fetch_assoc($result)) {
    if (!$startItem){
        echo ",";
    }
    $startItem=false;
    echo "{";
    echo '"itemImageSrc" :"'. $r["imageLocation"] . '",';
    echo '"itemImageAlt" :"'. $r["productName"] . '",';
    echo '"itemDescription" :"'. $r["productName"] . '",';
    echo '"itemPrice" :"'. $r["price"] . '"';
    echo "}";
}
echo ']';

echo $_POST[0];


*/
?>
<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Store</title>
  <link rel=stylesheet type="text/css" href="./styles/style-main.css">
  <script src="./scripts/menu-script.js"></script>
  <script src="./scripts/catalog.js"></script>
</head>
<body onload="init()">
	<div id="page-wrap">
		<nav>
			<ul>
  				<li id="icon"><a href="index.html"><img src="./images/atom-logo.png" alt="logo"></a></li>
				<a href="checkout.html"<li id="cart"></li></a>
  				<li class="menu-item"><a href="contact.html">Contact</a></li>
  				<li class="menu-item"><a href="store.html">Store</a></li>
  				<li class="menu-item"><a href="about.html">About</a></li>
  				<li id="underline"></li>
			</ul>
		</nav>
		<div id="store-text">
            <p>Your order has been processed</p>
		    <h3>Thank you for shopping with us</h3>
        </div>
    </div>
</body>
</html>    