
<?php
// A simple web site in Cloud9 that runs through Apache
// Press the 'Run' button on the top to start the web server,
// then click the URL that is emitted to the Output tab of the console

$servername = getenv('IP');

$username = getenv('C9_USER');
$password = "";
$database = "Products";
$dbport = 3306;

//Create connection
$db = new mysqli($servername, $username, $password,$database,$dbport);

//Check Connection
if ($db->connect_error){
    die("Connection failed: " . $db->connect_error);
}

//$stmt = $conn->query(select*)
/*
if($result->num_rows > 0){
    echo "{";
    while($row = mysqli_fetch_assoc($result)){
        //imageLocation
        //productName
        //manufacturer
        //price
        //availability
        //category
        
        echo '"'.$row["price"].'"';
        echo ',';
        //echo "pnum:".$row["pnum"]."\tpdesc: ".$row["pdesc"]."\tpsd: ".$row["psd"]."\tped: " . $row["ped"]. "<br>";
    }
    echo "}";
}else{
    echo "0 results";
}
*/

//echo "<script>";
//echo "catalog="
//echo "{";
//for (i =0;i<count($cat);i++){
        //$q = 'select * from Products where category ="' . $cat[$i] . '"limit 6';
        
//}
$category = array("Popular Items", "Strawberry Pi", "Strawberry Pi Accessories", "Industrial Compute Model");
$limit = 6;
echo "{";
foreach ($category as $cat){
    if (empty($_GET["manufacturer"])){
    	$query_project = "SELECT * FROM Products WHERE category='$cat' LIMIT $limit";
    }else{
    	$query_project = "SELECT * FROM Products WHERE category='$cat' AND manufacturer = '".$_GET["manufacturer"]."' LIMIT $limit";
    }
    $result = mysqli_query($db,$query_project);
    
    if ($category[0] != $cat){
        echo ",";
    }
    echo '"'.$cat.'" : [';
    
    
    $startItem=true;
    while($r = mysqli_fetch_assoc($result)) {
        if (!$startItem){
            echo ",";
        }
        $startItem=false;
        echo "{";
        echo '"itemImageSrc" :"'. $r["imageLocation"] . '",';
        echo '"itemImageAlt" :"'. $r["productName"] . '",';
        echo '"itemDescription" :"'. $r["productName"] . '",';
        echo '"itemPrice" :"'. $r["price"] . '"';
        echo "}";
    }
    echo ']';
}
echo "}";


    
    //$sth = mysqli_query($db,$query_project);
    //$rows = array();//array form
        //$rows[] = $r;//array form
/*
$test="%%";
$query_project = "SELECT * FROM Products where manufacturer LIKE '$test'";
$result = mysqli_query($db,$query_project);

$startItem=true;

echo ', "all" : [';
while($r = mysqli_fetch_assoc($result)) {
    if (!$startItem){
        echo ",";
    }
    echo "{";
    echo '"itemImageSrc" :"'. $r["imageLocation"] . '",';
    echo '"itemImageAlt" :"'. $r["manufacturer"] . '",';
    echo '"itemDescription" :"'. $r["productName"] . '",';
    echo '"itemPrice" :"'. $r["price"] . '"';
    echo "}";
    $startItem=false;
}
echo ']}';
*/

//print('{ "all":');//array form
//print json_encode($rows);//array form
//print '}';//array form



//require './scripts/getCategory.php';
//getCategory(["Popular Items"]);

?>