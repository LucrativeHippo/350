
<?php
// A simple web site in Cloud9 that runs through Apache
// Press the 'Run' button on the top to start the web server,
// then click the URL that is emitted to the Output tab of the console

$servername = getenv('IP');

$username = getenv('C9_USER');
$password = "";
$database = "Products";
$dbport = 3306;

//Create connection
$db = new mysqli($servername, $username, $password,$database,$dbport);

//Check Connection
if ($db->connect_error){
    die("Connection failed: " . $db->connect_error);
}



$query_project = "SELECT DISTINCT manufacturer FROM Products";
$result = mysqli_query($db,$query_project);


$startItem=true;
echo '[';
while($r = mysqli_fetch_assoc($result)) {
    if (!$startItem){
        echo ',';
    }
    $startItem=false;
    echo '"' . $r["manufacturer"] . '"';
}
echo ']';

?>