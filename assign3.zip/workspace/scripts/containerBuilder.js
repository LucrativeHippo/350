// temporary javascript thingy while we build the remove catalogs
/*     var catalog = 
         { "Popular Items": [
               {
                   "itemImageSrc" : "../images/Store_Products/Strawberry_Pi_3_Model_B copy.jpg",
                   "itemImageAlt" : "placeholder",
                   "itemDescription" : "<p> Strawberry Pi 3 Model B </p>",
                   "itemPrice" : "<p>$49.95</p>",
              },
               {
                   "itemImageSrc" : "../images/Store_Products/Strawberry_Pi_Zero copy.jpg",
                   "itemImageAlt" : "placeholder",
                   "itemDescription" : "<p> Strawberry Pi Zero </p>",
                   "itemPrice" : "<p>$29.95</p>",
               },
               {
                   "itemImageSrc" : "../images/Store_Products/placeholder.png",
                   "itemImageAlt" : "placeholder",
                   "itemDescription" : "<p> Strawberry Pi Case </p>",
                   "itemPrice" : "<p>10.95</p>",
               },
               {
                   "itemImageSrc" : "../images/Store_Products/placeholder.png",
                   "itemImageAlt" : "placeholder",
                   "itemDescription" : "<p> Strawberry Pi Extension Kit </p>",
                   "itemPrice" : "<p>$149.95</p>",
                   "itemPopular" : "false"
               }
          ],
	 "Strawberry Pi": [
               {
                   "itemImageSrc" : "../images/Store_Products/Strawberry_Pi_3_Model_B copy.jpg",
                   "itemImageAlt" : "placeholder",
                   "itemDescription" : "<p> Strawberry Pi 3 Model B </p>",
                   "itemPrice" : "<p>$49.95</p>",
               },
               {
                   "itemImageSrc" : "../images/Store_Products/Strawberry_Pi_Zero copy.jpg",
                   "itemImageAlt" : "placeholder",
                   "itemDescription" : "<p> Strawberry Pi Zero </p>",
                   "itemPrice" : "<p>$29.95</p>",
               },
               {
                   "itemImageSrc" : "../images/Store_Products/placeholder.png",
                   "itemImageAlt" : "placeholder",
                   "itemDescription" : "<p> Strawberry Pi Case </p>",
                   "itemPrice" : "<p>10.95</p>",
              },
               {
                   "itemImageSrc" : "../images/Store_Products/placeholder.png",
                   "itemImageAlt" : "placeholder",
                   "itemDescription" : "<p> Strawberry Pi Extension Kit </p>",
                   "itemPrice" : "<p>$149.95</p>",
               }
          ]
	 };
*/

     

var buttonListeners;

var popularItems = catalog["Popular Items"];

document.write( '<div class="feature-container">' );

for ( var i = 0; i < popularItems.length; i++) {

 	document.writeln('<div class="feature-box">');
	document.write('<img src="');
	document.writeln(popularItems[i].itemImageSrc);
	document.write('" alt="');
    document.write(popularItems[i].itemImageAlt);
	document.writeln('">');

	document.write('<div class="feature-box-model">');
	document.write(popularItems[i].itemDescription);
	document.writeln('</div>');

	document.write('<div class="feature-box-price">');
	document.write(popularItems[i].itemPrice);
	document.writeln('</div>');

	var id = "addToCart" + i;
	document.writeln('<button id='); 
	document.writeln( id + " type="button">Add to Cart</button>');
	

	buttonListerners.id = popularItems[i].itemDescription;
	document.writeln('</div>');

}

	document.writeln('</div>');

alert("Done");