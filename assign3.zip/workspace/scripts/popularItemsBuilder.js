/*
document.getElementById("shop-button").addEventListener("click", function(){startShopping()});

document.write( '<div class="feature-container">' );



//for ( var i = 0; i < currentItems.length; i++) {
for ( var i = 0; i < 3; i++) { //in case you want to display at most 3

 	document.writeln('<div class="feature-box">');
	document.write('<img src="');
	document.writeln(currentItems[i].itemImageSrc);
	document.write('" alt="');
        document.write(currentItems[i].itemImageAlt);
	document.writeln('">');

	document.write('<div class="feature-box-model">');
	document.write(currentItems[i].itemDescription);
	document.writeln('</div>');

	document.write('<div class="feature-box-price">');
	document.write(currentItems[i].itemPrice);
	document.writeln('</div>');
    
	var id = "addToCart" + "Popular Items" + i;
	document.write('<button id="'); 
	document.writeln( id + '" type="button">Add to Cart</button><BR>');

	let c = currentItems[i];
	document.getElementById( id ).addEventListener("click", function(){addToShoppingList(c)});

	document.writeln('</div>');

}

	document.writeln('</div>');
*/

document.writeln( '<div class="feature">' );

// Note that for my personal solution, I am maintaining a separate list of popular items
// and a separate list of all the other items. Yu may have done things a little differently

for (x in catalog ) {
	if ( x == "Popular Items")  {
		///Build the header
		document.writeln( '<div class=feature-text>');
		document.write( x );
		document.writeln( '</div>');
		
		// build feature container
		document.write( '<div class="feature-container">' );
		var currentItems = catalog[x];
		for ( var i = 0; i < currentItems.length; i++) {
			document.writeln('<div class="feature-box">');
			document.write('<img src="');
			document.writeln(currentItems[i].itemImageSrc);
			document.write('" alt="');
        	document.write(currentItems[i].itemImageAlt);
			document.writeln('">');

			document.write('<div class="feature-box-model">');
			document.write(currentItems[i].itemDescription);
			document.writeln('</div>');

			document.write('<div class="feature-box-price">');
			document.write(currentItems[i].itemPrice);
			document.writeln('</div>');
			
			// I construct a unique id for each item with the prefix
			// add-to-Cart, it's category (which forms a title) and a unique integer
			
			var id = "addToCart" + x + i;
			document.write('<button id="'); 
			document.writeln( id + '" type="button">Add to Cart</button><BR>');
			let c = currentItems[i];
			document.getElementById( id ).addEventListener("click", function(){addToShoppingList(c)});
			document.writeln('</div>');

		}
		
		document.writeln('</div>  <!-- end of feature-container-->');
		document.writeln('<div class="clearboth"></div>');
			
	}
}

function startShopping() {
	location.href = "store.html";
} 
